﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Datalogics.PDF2IMG;


/*

 * Disclaimer: Samples are designed for demonstration purposes and are not intended for production usage.
 *
 * Copyright (c) 2019, Datalogics, Inc. All rights reserved.
 */
namespace PDF2IMGDotNETSample
{

    class Program
    {
          static void Main(string[] args)
        {

            FileStream fs = File.Create("temp.temp");

            String inputFilePDF = "C:\\Datalogics\\PDF2IMGPremium3.3\\DotNETSample\\ducky.pdf";
            String inputFileXPS = "C:\\Datalogics\\PDF2IMGPremium3.3\\DotNETSample\\brownfox.xps";

            String outputFolder = "";
            String outputPathPDF = "C:\\Datalogics\\PDF2IMGPremium3.3\\DotNETSample\\imagePDF.png";
            String outputPathXPS = "C:\\Datalogics\\PDF2IMGPremium3.3\\DotNETSample\\imageXPS.png";

            IList<String> fonts = new List<String>();
            Console.WriteLine("Processing " + inputFilePDF);

            using (PDF2IMG mypdf2img = new PDF2IMG(fonts, false, false))
            {
                ImageConversionOptions ico = new ImageConversionOptions();
                ico.BitsPerChannel = 8;
                ico.ColorSpace = ColorSpace.RGB;
                ico.HorizontalResolution = 300;
                ico.VerticalResolution = 300;
                ico.OutputType = OutputType.PNG;

                mypdf2img.LoadInput(inputFilePDF, null);
                mypdf2img.SetImageConversionOptions(ico);
                mypdf2img.ConvertPageToImage(1, outputPathPDF);
            }
            Console.WriteLine("Finished!");


            Console.WriteLine("Processing " + inputFileXPS);

            using (PDF2IMG mypdf2img = new PDF2IMG(fonts, false, false))
            {
                ImageConversionOptions ico = new ImageConversionOptions();
                ico.BitsPerChannel = 8;
                ico.ColorSpace = ColorSpace.RGB;
                ico.HorizontalResolution = 300;
                ico.VerticalResolution = 300;
                ico.OutputType = OutputType.PNG;

                mypdf2img.LoadInput(inputFileXPS, null);
                mypdf2img.SetImageConversionOptions(ico);
                mypdf2img.ConvertPageToImage(1, outputPathXPS);
            }

            Console.WriteLine("Finished!");
         }
    }
}
