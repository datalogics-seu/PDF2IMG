PDF2IMG in-memory conversion sample
==================================
1) Make a copy of your PDF2IMG folder 

2) Add the  package to the new folder:  
pdf2img_x64Bit-InMem.sln
pdf2img-InMemory.cpp
input.pdf

3) If you are using a license managed version of PDF2IMG, you will need to copy the .lic file to the destination folder where the .exe is created (e.g. /x64/debug)
 
4) Open .SLN file, build, run.  

The program (pdf2img-InMem.exe ) will open input.pdf and create out.tif in that folder.