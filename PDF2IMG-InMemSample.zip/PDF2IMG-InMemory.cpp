// pdf2img-InMemory.cpp : Defines the entry point for the console application.
//

// #include "stdafx.h" 

#include "pdf2imglib.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#if defined(UNIX_ENV)
#include <ctype.h>
#endif
/*
int _tmain(int argc, _TCHAR* argv[])
{
*/	
	/*  Copyright 2007-2021 Datalogics, Inc. All rights reserved.

    This program tests the PDF2IMG C API functionality for reading PDFs
    from blocks of memory and writing PDFs to blocks of memory.
*/



int main(int argc, char *argv[])
{

    ImageConversion     iC = 0;
    int                 retVal = 0,
                        pdf2imgErrVal = 0;
    char                *inputName = "input.pdf";
    FILE                *inputFile = 0;
    unsigned char       *picBuf = 0;
    unsigned int        picBufSize = 0;

    if (argc >= 2)
        inputName = argv[1];

    if (!(inputFile = fopen(inputName, "rb")) )
    {
        printf("Could not open %s; halting.\n", inputName);
        return 1;
    }
    fseek(inputFile, 0, SEEK_END);
    picBufSize = ftell(inputFile);
    fseek(inputFile, 0, SEEK_SET);
    if (!(picBuf = new unsigned char[picBufSize]) )
    {
        printf("Could not allocate %d bytes for input; halting.\n", picBufSize);
        fclose(inputFile);
        return 1;
    }
    if (picBufSize != fread(picBuf, 1, picBufSize, inputFile))
    {
        printf("Could not read %s; halting.\n", inputName);
        fclose(inputFile);
        delete(picBuf);
        return 1;
    }
    fclose(inputFile);
    if (pdf2img_init(NULL, 0))
    {
        printf("Error initializing pdf2img; halting.\n");
        return 1;
    }

    iC = pdf2img_new_memconversion(picBuf, picBufSize);
    if ((0 == iC) || (0 > pdf2img_get_num_pages(iC)) )
    {
        printf("Error opening %s from memory; halting\n", inputName);
        pdf2img_term();
        return -2;
    }
	//time();
    printf("Opened %s (%d pages) from memory block. Converting first page...\n",
        inputName, pdf2img_get_num_pages(iC));
    pdf2img_set_output_type(iC, TIFFoutput);
    pdf2img_convert_page(iC, 1, NULL);  // pass NULL to make a "memory" conversion
    size_t memNeeded = pdf2img_get_pagememsize(iC);
    if (memNeeded > 0)
    {
        void *picBuf = malloc(memNeeded);
        if (picBuf)
        {
            FILE *outGr = 0;
            outGr = fopen("out.tif", "wb");
            
            pdf2img_get_pagemem(iC, picBuf, (unsigned int) memNeeded);
            fwrite(picBuf, 1, memNeeded, outGr);
            fclose(outGr);
            free(picBuf);

            pdf2img_release_pagemem(iC);
        }
    }
    pdf2img_destroy_conversion(iC);

    pdf2img_term();

    return retVal;
}
	
	
	
	
/*	
	
	return 0;
}
*/
